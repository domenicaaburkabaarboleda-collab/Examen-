export function getImagenAnillo(material = "") {
  const mat = material.toLowerCase();

  if (mat.includes("oro")) return "img/oro.jpg";
  if (mat.includes("plata")) return "img/plata.jpg";
  if (mat.includes("diamante")) return "img/diamante.jpg";
  if (mat.includes("esmeralda")) return "img/esmeralda.jpg";

  return "img/default.jpg";
}