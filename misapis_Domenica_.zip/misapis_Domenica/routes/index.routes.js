import { Router } from "express";
import anillosRouter from "./anillos.routes.js";

const router = Router();

router.use("/anillos", anillosRouter);

export default router;