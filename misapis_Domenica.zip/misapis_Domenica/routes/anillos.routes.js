import { Router } from "express";
import {
  listarAnillos,
  crearAnillo,
  actualizarAnillo,
  eliminarAnillo
} from "../controllers/anillos.controller.js";

const router = Router();

router.get("/", listarAnillos);
router.post("/", crearAnillo);
router.put("/:id", actualizarAnillo);
router.delete("/:id", eliminarAnillo);

export default router;