import Anillo from "../models/Anillo.js";
import { getImagenAnillo } from "../utils/getImagenAnilloLocal.js";

// LISTAR
export const listarAnillos = async (req, res) => {
  try {
    const data = await Anillo.find();
    res.json(data);
  } catch (err) {
    res.status(500).json({ mensaje: "Error al listar anillos", err });
  }
};

// CREAR
export const crearAnillo = async (req, res) => {
  try {
    const { nombre, material, talla, precio, descripcion } = req.body;

    const imagen = getImagenAnillo(material);

    const nuevo = new Anillo({
      nombre,
      material,
      talla,
      precio,
      descripcion,
      imagen
    });

    await nuevo.save();

    res.status(201).json({
      mensaje: "Anillo registrado correctamente 💍",
      anillo: nuevo
    });
  } catch (err) {
    res.status(400).json({ mensaje: "Error al crear anillo", err });
  }
};

// ACTUALIZAR
export const actualizarAnillo = async (req, res) => {
  try {
    if (req.body.material) {
      req.body.imagen = getImagenAnillo(req.body.material);
    }

    const actualizado = await Anillo.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    res.json({
      mensaje: "Anillo actualizado 🔄",
      anillo: actualizado
    });

  } catch (err) {
    res.status(400).json({ mensaje: "Error al actualizar", err });
  }
};

// ELIMINAR
export const eliminarAnillo = async (req, res) => {
  try {
    await Anillo.findByIdAndDelete(req.params.id);
    res.json({ mensaje: "Anillo eliminado ❌" });
  } catch (err) {
    res.status(400).json({ mensaje: "Error al eliminar", err });
  }
};