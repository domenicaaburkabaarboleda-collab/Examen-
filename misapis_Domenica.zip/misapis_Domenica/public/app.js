const API = "http://localhost:3000/api/anillos";

// ===============================
//  AUTO-IMAGEN SEGÚN EL NOMBRE (solo para EDITAR)
// ===============================
function obtenerImagen(nombre) {
  nombre = nombre.toLowerCase();

  if (nombre.includes("oro")) return "img/oro.jpg";
  if (nombre.includes("plata")) return "img/plata.jpg";
  if (nombre.includes("diamante")) return "img/diamante.jpg";
  if (nombre.includes("esmeralda")) return "img/esmeralda.jpg";

  return "img/default.jpg"; 
}

// ===============================
//  CARGAR ANILLOS
// ===============================
async function cargarAnillos() {
  try {
    const res = await fetch(API);
    const data = await res.json();
    const cont = document.getElementById("anillosContainer");
    cont.innerHTML = "";

    data.forEach(a => {
      cont.innerHTML += `
        <div class="card">
          <img src="${a.imagen}" alt="${a.nombre}">
          <h3>${a.nombre}</h3>
          <p><strong>Material:</strong> ${a.material}</p>
          <p><strong>Talla:</strong> ${a.talla}</p>
          <p><strong>Precio:</strong> $${a.precio}</p>
          <p>${a.descripcion}</p>

          <button onclick="editarAnillo('${a._id}')">✏️ Editar</button>
          <button onclick="eliminarAnillo('${a._id}')">🗑️ Eliminar</button>
        </div>
      `;
    });

  } catch (error) {
    console.error("Error al cargar anillos:", error);
  }
}

document.addEventListener("DOMContentLoaded", cargarAnillos);

// ===============================
//  CREAR ANILLO
// ===============================
async function crearAnillo() {
  const nombre = document.getElementById("nombre").value.trim();
  const material = document.getElementById("material").value.trim();
  const talla = document.getElementById("talla").value.trim();
  const precio = document.getElementById("precio").value.trim();
  const descripcion = document.getElementById("descripcion").value.trim();

  if (!nombre || !material || !talla || !precio) {
    alert("Faltan campos obligatorios");
    return;
  }

  // YA NO SE ENVÍA IMAGEN → backend la genera
  const nuevoAnillo = {
    nombre,
    material,
    talla: Number(talla),
    precio: Number(precio),
    descripcion
  };

  const res = await fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(nuevoAnillo)
  });

  if (res.ok) {
    alert("💍 Anillo registrado con éxito!");
    limpiarFormulario();
    cargarAnillos();
  } else {
    alert("❌ Error al registrar anillo");
  }
}

// ===============================
//  ELIMINAR ANILLO
// ===============================
async function eliminarAnillo(id) {
  if (!confirm("¿Seguro quieres eliminar este anillo?")) return;

  const res = await fetch(`${API}/${id}`, { method: "DELETE" });

  if (res.ok) {
    alert("Anillo eliminado");
    cargarAnillos();
  } else {
    alert("No se pudo eliminar");
  }
}

// ===============================
//  EDITAR ANILLO
// ===============================
async function editarAnillo(id) {
  const nuevoNombre = prompt("Nuevo nombre del anillo:");
  if (!nuevoNombre) return;

  const res = await fetch(`${API}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      nombre: nuevoNombre,
      imagen: obtenerImagen(nuevoNombre)
    })
  });

  if (res.ok) {
    alert("Anillo actualizado");
    cargarAnillos();
  } else {
    alert("No se pudo actualizar");
  }
}

// ===============================
//  LIMPIAR FORMULARIO
// ===============================
function limpiarFormulario() {
  document.getElementById("nombre").value = "";
  document.getElementById("material").value = "";
  document.getElementById("talla").value = "";
  document.getElementById("precio").value = "";
  document.getElementById("descripcion").value = "";
}