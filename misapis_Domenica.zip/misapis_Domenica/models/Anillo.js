import mongoose from 'mongoose';

const anilloSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  material: { type: String, required: true },
  talla: { type: Number, required: true },
  precio: { type: Number, required: true },
  descripcion: { type: String, default: 'Anillo premium' },
  imagen: { type: String, required: true },
  fechaRegistro: { type: Date, default: Date.now },
  marca: { type: String, default: 'Aurius Rings' }
});

export default mongoose.model('Anillo', anilloSchema);